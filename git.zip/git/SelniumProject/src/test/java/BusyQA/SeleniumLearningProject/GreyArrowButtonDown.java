package BusyQA.SeleniumLearningProject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class GreyArrowButtonDown {
    public static void main(String[] args) {
        // Set the path to the GeckoDriver
        System.setProperty("webdriver.gecko.driver", "C:\\driver\\geckodriver.exe");

        // Initialize WebDriver
        WebDriver driver = new FirefoxDriver();

        try {
            // Open the React application
            driver.get("http://localhost:3000");

            // Wait for the button to load
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
            WebElement button = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.cssSelector(".w-[92px].h-[92px].bg-[#808080].rounded-[57px]")
            ));

            // Verify button's properties
            String bgColor = button.getCssValue("background-color");
            System.out.println("Background color: " + bgColor);

            int buttonWidth = button.getSize().getWidth();
            int buttonHeight = button.getSize().getHeight();
            System.out.println("Button width: " + buttonWidth + ", height: " + buttonHeight);

            // Verify the SVG arrow
            WebElement svgElement = button.findElement(By.tagName("svg"));
            String svgTransform = svgElement.getAttribute("class");
            System.out.println("SVG transform: " + svgTransform);

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            // Close the browser
            driver.quit();
        }
    }
}

