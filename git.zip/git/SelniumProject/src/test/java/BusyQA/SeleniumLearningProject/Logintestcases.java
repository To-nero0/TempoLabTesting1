package BusyQA.SeleniumLearningProject;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;
import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.AfterTest;
import org.openqa.selenium.chrome.ChromeDriver;


public class Logintestcases {
	WebDriver driver;
 
	@Test
  public void WrongUsernameandPassword() {
	  driver.findElement(By.name("username")).sendKeys("user");
	  driver.findElement(By.name("password")).sendKeys("admin0123");
	  String OrangeTitle = "OrangeHRM";
	  
     
     
	  if (driver.getTitle().equals(OrangeTitle)) {
          System.out.println();
         
              } else { 
            	 
          System.out.println("Invalid credentials");
          }
 }
	
	public void CorrectUsernameandWrongPassword() {
		  driver.findElement(By.name("username")).sendKeys("Admin");
		  driver.findElement(By.name("password")).sendKeys("user123");
	 String OrangeTitle = "OrangeHRM";
	  
     
     
	  if (driver.getTitle().equals(OrangeTitle)) {
         System.out.println();
        
             } else { 
           	 
         System.out.println("Invalid credentials");
         }
	  }

	public void CorrectUsernameandPassword() {
		  driver.findElement(By.name("username")).sendKeys("Admin");
		  driver.findElement(By.name("password")).sendKeys("admin123");
	  String OrangeTitle = "OrangeHRM";
	  
	     
	     
	  if (driver.getTitle().equals(OrangeTitle)) {
          System.out.println();
         
              } else { 
            	 
          System.out.println("Invalid credentials");
          }
	  }

	@BeforeTest
  public void beforeTest() {
		driver = new ChromeDriver();
		  driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		  driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
  }

  @AfterTest
  public void afterTest() {
  }

}
