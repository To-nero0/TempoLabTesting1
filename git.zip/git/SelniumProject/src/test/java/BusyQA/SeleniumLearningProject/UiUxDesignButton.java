package BusyQA.SeleniumLearningProject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.interactions.Actions;

public class UiUxDesignButton {

    public static void main(String[] args) {
        // Path to the Firefox WebDriver
        System.setProperty("webdriver.gecko.driver", "C:\\driver\\geckodriver.exe");

        // Initialize WebDriver
        FirefoxOptions options = new FirefoxOptions();
        WebDriver driver = new FirefoxDriver(options);

        try {
            // Navigate to the application where UiUxDesignButton is rendered
            driver.get("http://localhost:3000");

            // Maximize the browser window
            driver.manage().window().maximize();

            // Locate the UI/UX Design Button
            WebElement button = driver.findElement(By.cssSelector(".h-[54px].inline-flex"));

            // Verify button visibility
            if (!button.isDisplayed()) {
                throw new Exception("UI/UX Design button is not displayed.");
            }

            // Verify button dimensions
            int height = button.getSize().getHeight();
            int width = button.getSize().getWidth();
            if (height != 54) {
                throw new Exception("Button height is incorrect. Expected: 54, Found: " + height);
            }
            if (width <= 0) {
                throw new Exception("Button width is invalid.");
            }

            // Verify background color in normal state
            String normalBackgroundColor = button.getCssValue("background-color");
            if (!normalBackgroundColor.equals("rgba(207, 212, 220, 1)")) {
                throw new Exception("Button's normal background color is incorrect.");
            }

            // Hover over the button and verify hover background color
            Actions actions = new Actions(driver);
            actions.moveToElement(button).perform();

            String hoverBackgroundColor = button.getCssValue("background-color");
            if (!hoverBackgroundColor.equals("rgba(242, 243, 246, 1)")) {
                throw new Exception("Button's hover background color is incorrect.");
            }

            // Verify button text
            WebElement buttonText = button.findElement(By.cssSelector(".text-black.text-xl"));
            String actualText = buttonText.getText();
            if (!actualText.equals("UI/UX Design")) {
                throw new Exception("Button text is incorrect. Expected: 'UI/UX Design', Found: " + actualText);
            }

            System.out.println("All validations passed successfully!");

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            // Close the browser
            driver.quit();
        }
    }
}
