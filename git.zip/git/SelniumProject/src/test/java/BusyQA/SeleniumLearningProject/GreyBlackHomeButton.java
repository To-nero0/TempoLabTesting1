package BusyQA.SeleniumLearningProject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class GreyBlackHomeButton {
    public static void main(String[] args) {
        // Set the GeckoDriver path
        System.setProperty("webdriver.gecko.driver", "C:\\driver\\geckodriver.exe");

        // Initialize WebDriver
        WebDriver driver = new FirefoxDriver();

        try {
            // Open the React application
            driver.get("http://localhost:3000");

            // Wait for the button to appear
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
            WebElement homeButton = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.cssSelector(".h-[74px].rounded-[60px].border.border-[#0c0c0c]")
            ));

            // Validate button text
            String buttonText = homeButton.getText();
            System.out.println("Button Text: " + buttonText);
            if (!buttonText.equals("Home")) {
                System.out.println("Error: Button text does not match 'Home'.");
            }

            // Validate CSS properties
            String borderColor = homeButton.getCssValue("border-color");
            String textColor = homeButton.getCssValue("color");
            String fontSize = homeButton.getCssValue("font-size");

            System.out.println("Border Color: " + borderColor);
            System.out.println("Text Color: " + textColor);
            System.out.println("Font Size: " + fontSize);

            // Validate dimensions
            int buttonWidth = homeButton.getSize().getWidth();
            int buttonHeight = homeButton.getSize().getHeight();
            System.out.println("Button Width: " + buttonWidth + ", Height: " + buttonHeight);

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            // Close the browser
            driver.quit();
        }
    }
}
