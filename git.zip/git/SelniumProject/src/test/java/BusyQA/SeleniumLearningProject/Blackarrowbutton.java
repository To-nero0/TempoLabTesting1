package BusyQA.SeleniumLearningProject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class Blackarrowbutton {

    public static void main(String[] args) {
        // Set GeckoDriver path
        System.setProperty("webdriver.gecko.driver", "C:\\driver\\geckodriver.exe");

        // Configure Firefox options
        FirefoxOptions options = new FirefoxOptions();
        options.addArguments("--start-maximized");

        // Initialize WebDriver
        WebDriver driver = new FirefoxDriver(options);

        try {
            // Navigate to the local React app
            driver.get("http://localhost:3000");

            // Explicit wait to ensure the page loads
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

            // Locate the BlackArrowButton element
            WebElement button = wait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector("button.w-\\[92px\\]")));

            // Validate the button is displayed
            if (button.isDisplayed()) {
                System.out.println("Black Arrow Button is displayed on the page.");
            } else {
                System.out.println("Black Arrow Button is not displayed on the page.");
            }

            // Check if the SVG exists inside the button
            WebElement svg = button.findElement(By.tagName("svg"));
            if (svg != null) {
                System.out.println("SVG arrow icon is present inside the button.");
            }

            // Validate button styling (example: background color)
            String backgroundColor = button.getCssValue("background-color");
            System.out.println("Button background color: " + backgroundColor);

            // Click the button
            button.click();
            System.out.println("Button clicked successfully.");

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            // Quit the driver
            driver.quit();
        }
    }
}
