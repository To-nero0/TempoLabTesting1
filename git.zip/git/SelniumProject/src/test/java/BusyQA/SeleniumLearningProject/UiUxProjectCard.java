package BusyQA.SeleniumLearningProject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;

public class UiUxProjectCard {

    public static void main(String[] args) {
        // Set the path to the geckodriver executable
        System.setProperty("webdriver.gecko.driver", "C:\\driver\\geckodriver.exe");

        // Initialize the Firefox WebDriver
        WebDriver driver = new FirefoxDriver();

        try {
            // Navigate to the web page containing the UI/UX Project Card
            driver.get("http://localhost:3000"); // Replace with the actual URL of your project

            // Maximize the browser window
            driver.manage().window().maximize();

            // Locate the UI/UX Project Card element by its CSS selector
            WebElement projectCard = driver.findElement(By.cssSelector(".inline-block.relative.cursor-pointer"));

            // Create an Actions object for mouse hover actions
            Actions actions = new Actions(driver);

            // Perform mouse hover on the project card to trigger the hover state
            actions.moveToElement(projectCard).perform();

            // Wait for a few seconds to observe the hover effect
            Thread.sleep(2000);

            // Capture details about the hover effect (if needed)
            WebElement hoverElement = driver.findElement(By.cssSelector("svg[width='456'][height='618']"));
            if (hoverElement.isDisplayed()) {
                System.out.println("Hover effect displayed successfully.");
            } else {
                System.out.println("Hover effect not displayed.");
            }

            // Perform any additional validation or interaction as needed

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            // Close the browser
            driver.quit();
        }
    }
}
