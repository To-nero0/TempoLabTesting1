package BusyQA.SeleniumLearningProject;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import java.time.Duration;
import org.openqa.selenium.Dimension;

public class FlowingSkillBanner {
    public static void main(String[] args) {
        // Set the path to the geckodriver executable
        System.setProperty("webdriver.gecko.driver", "C:\\driver\\geckodriver.exe");

        // Initialize Firefox WebDriver
        FirefoxOptions options = new FirefoxOptions();
        WebDriver driver = new FirefoxDriver(options);
        
        try {
            // Navigate to the page containing the FlowingSkillsBanner component
            driver.get("http://your-app-url.com"); // Replace with the URL of your React app
            
            // Set the window size for better testing visibility (optional)
            driver.manage().window().setSize(new Dimension(1440, 900));

            // Wait for the marquee animation to load and check if it's visible
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
            WebElement marqueeContainer = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".animate-marquee")));

            // Check if the marquee animation is running
            if (marqueeContainer.isDisplayed()) {
                System.out.println("Marquee animation is visible and running.");
            } else {
                System.out.println("Marquee animation is not visible.");
            }

            // Verify that all skills are displayed in the banner
            WebElement firstSkill = driver.findElement(By.xpath("//div[text()='UX Design']"));
            WebElement secondSkill = driver.findElement(By.xpath("//div[text()='App Design']"));
            WebElement thirdSkill = driver.findElement(By.xpath("//div[text()='Dashboard']"));
            WebElement fourthSkill = driver.findElement(By.xpath("//div[text()='Wireframe']"));
            WebElement fifthSkill = driver.findElement(By.xpath("//div[text()='User Research']"));

            // Check if skills are displayed properly
            if (firstSkill.isDisplayed() && secondSkill.isDisplayed() && thirdSkill.isDisplayed() &&
                fourthSkill.isDisplayed() && fifthSkill.isDisplayed()) {
                System.out.println("All skills are displayed correctly.");
            } else {
                System.out.println("Some skills are not displayed.");
            }

        } catch (Exception e) {
            System.out.println("An error occurred: " + e.getMessage());
        } finally {
            // Close the driver
            driver.quit();
        }
    }
}
