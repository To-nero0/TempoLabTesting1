package BusyQA.SeleniumLearningProject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;

public class TradeMarkLogo {

    public static void main(String[] args) {
        // Set the path to the geckodriver executable
        System.setProperty("webdriver.gecko.driver", "C:\\driver\\geckodriver.exe");

        // Initialize Firefox WebDriver
        FirefoxOptions options = new FirefoxOptions();
        WebDriver driver = new FirefoxDriver(options);

        try {
            // Navigate to the local server hosting the React app
            driver.get("http://localhost:3000");

            // Maximize the browser window
            driver.manage().window().maximize();

            // Locate the TrademarkLogo container
            WebElement logoContainer = driver.findElement(By.xpath("//div[contains(@class, 'w-[307px] h-[86px]')]"));
            if (!logoContainer.isDisplayed()) {
                throw new Exception("TrademarkLogo container is not displayed.");
            }

            // Verify the background color of the container
            String backgroundColor = logoContainer.getCssValue("background-color");
            if (!backgroundColor.equals("rgba(51, 51, 51, 1)")) {
                throw new Exception("Background color does not match the expected value.");
            }

            // Verify the circular container inside TrademarkLogo
            WebElement circularContainer = logoContainer.findElement(By.xpath(".//div[contains(@class, 'w-[46px] h-[46px]')]"));
            if (!circularContainer.isDisplayed()) {
                throw new Exception("Circular container is not displayed.");
            }

            // Verify the presence of the SVG elements
            WebElement svgElement = circularContainer.findElement(By.tagName("svg"));
            if (!svgElement.isDisplayed()) {
                throw new Exception("SVG inside the circular container is not displayed.");
            }

            System.out.println("All validations passed successfully.");

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            // Quit the browser
            driver.quit();
        }
    }
}
