package BusyQA.SeleniumLearningProject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class BlackHomeButton {

    public static void main(String[] args) {
        // Set the path to the GeckoDriver executable
        System.setProperty("webdriver.gecko.driver", "C:\\driver\\geckodriver.exe");

        // Configure Firefox options
        FirefoxOptions options = new FirefoxOptions();
        options.addArguments("--start-maximized");

        // Initialize WebDriver
        WebDriver driver = new FirefoxDriver(options);

        try {
            // Navigate to the React application (update URL as necessary)
            driver.get("http://localhost:3000");

            // Wait for the button to load
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
            WebElement homeButton = wait.until(ExpectedConditions.presenceOfElementLocated(
                By.cssSelector("div.h-\\[74px\\].bg-\\[\\#10110e\\]"))
            );

            // Validate button visibility
            if (homeButton.isDisplayed()) {
                System.out.println("The 'Home' button is displayed.");
            } else {
                System.out.println("The 'Home' button is not displayed.");
            }

            // Validate button text
            WebElement buttonText = homeButton.findElement(By.cssSelector("div.text-white"));
            String text = buttonText.getText();
            if ("Home".equals(text)) {
                System.out.println("The button text is correctly set to 'Home'.");
            } else {
                System.out.println("The button text is incorrect: " + text);
            }

            // Validate button background color
            String backgroundColor = homeButton.getCssValue("background-color");
            System.out.println("Button background color: " + backgroundColor);

            // Validate border style
            String border = homeButton.getCssValue("border");
            System.out.println("Button border: " + border);

            // Simulate a click on the button
            homeButton.click();
            System.out.println("Button clicked successfully.");

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            // Close the browser
            driver.quit();
        }
    }
}
