package BusyQA.SeleniumLearningProject;


	import org.openqa.selenium.By;
	import org.openqa.selenium.WebDriver;
	import org.openqa.selenium.WebElement;
	import org.openqa.selenium.firefox.FirefoxDriver;
	import org.openqa.selenium.firefox.FirefoxOptions;

	public class Whitesearchbutton {
	    public static void main(String[] args) {
	        // Set the path to the geckodriver
	        System.setProperty("webdriver.gecko.driver", "C:\\driver\\geckodriver.exe");
	        
	        // Set up FirefoxOptions
	        FirefoxOptions options = new FirefoxOptions();
	        
	        // Instantiate the Firefox WebDriver
	        WebDriver driver = new FirefoxDriver(options);
	        
	        // Navigate to the page containing the WhiteSearchButton component
	        driver.get("http://localhost:3000"); 

	        // Locate the white search button by its class name
	        WebElement searchButton = driver.findElement(By.className("w-[92px]"));
	        
	        // Test: Check if the button is displayed
	        if (searchButton.isDisplayed()) {
	            System.out.println("WhiteSearchButton is displayed.");
	        } else {
	            System.out.println("WhiteSearchButton is NOT displayed.");
	        }

	        // Test: Simulate clicking the search button
	        searchButton.click();
	        
	        // Add any further actions or assertions if needed
	        
	        // Close the browser after the test
	        driver.quit();
	    }
	}
