package BusyQA.SeleniumLearningProject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.WebDriverException;

import java.time.Duration;

public class PlayButton {
    public static void main(String[] args) {
        // Set path to geckodriver
        System.setProperty("webdriver.gecko.driver", "C:\\driver\\geckodriver.exe");

        // Initialize Firefox options
        FirefoxOptions options = new FirefoxOptions();
        options.setHeadless(false);  // Set to true for headless (background) testing

        // Initialize Firefox WebDriver
        WebDriver driver = new FirefoxDriver(options);

        try {
            // Navigate to the React app (replace with actual URL)
            driver.get("http://localhost:3000");  // URL where the PlayButton component is located

            // Wait for the Play button to be visible and clickable
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
            WebElement playButton = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("button.bg-gray-800")));

            // Verify that the Play button is displayed and enabled
            if (playButton.isDisplayed() && playButton.isEnabled()) {
                System.out.println("Play button is visible and clickable.");
            } else {
                System.out.println("Play button is not visible or clickable.");
            }

            // Hover over the button to check hover effect
            Actions actions = new Actions(driver);
            actions.moveToElement(playButton).perform();  // Hover over the button
            System.out.println("Hovered over the Play button.");

            // Click the Play button to test interaction
            playButton.click();
            System.out.println("Play button clicked.");

            // Wait for the expected action after click (adjust according to your app's behavior)
            wait.until(ExpectedConditions.urlContains("expected-action-page")); // Modify as necessary

            System.out.println("Test completed successfully.");

        } catch (WebDriverException e) {
            e.printStackTrace();
            System.out.println("An error occurred during test execution.");
        } finally {
            // Close the browser
            driver.quit();
        }
    }
}
