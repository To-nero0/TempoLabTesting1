package BusyQA.SeleniumLearningProject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class Blacksearchbutton {

    public static void main(String[] args) {
        // Set the path to the GeckoDriver executable
        System.setProperty("webdriver.gecko.driver", "C:\\driver\\geckodriver.exe");

        // Configure Firefox options
        FirefoxOptions options = new FirefoxOptions();
        options.addArguments("--start-maximized");

        // Initialize WebDriver
        WebDriver driver = new FirefoxDriver(options);

        try {
            // Navigate to the React application (update URL as necessary)
            driver.get("http://localhost:3000");

            // Wait for the button to load
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
            WebElement searchButton = wait.until(ExpectedConditions.presenceOfElementLocated(
                By.cssSelector("div.h-16.bg-\\[\\#10110e\\].rounded-\\[60px\\]"))
            );

            // Validate button visibility
            if (searchButton.isDisplayed()) {
                System.out.println("The 'Search' button is displayed.");
            } else {
                System.out.println("The 'Search' button is not displayed.");
            }

            // Validate button styling
            String backgroundColor = searchButton.getCssValue("background-color");
            System.out.println("Button background color: " + backgroundColor);

            String borderRadius = searchButton.getCssValue("border-radius");
            System.out.println("Button border radius: " + borderRadius);

            // Simulate a click on the button
            searchButton.click();
            System.out.println("Button clicked successfully.");

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            // Close the browser
            driver.quit();
        }
    }
}
