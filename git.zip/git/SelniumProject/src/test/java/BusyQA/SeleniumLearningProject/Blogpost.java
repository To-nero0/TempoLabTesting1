package BusyQA.SeleniumLearningProject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class Blogpost {

    public static void main(String[] args) {
        // Set path to GeckoDriver
        System.setProperty("webdriver.gecko.driver", "C:\\driver\\geckodriver.exe");

        // Configure Firefox browser
        FirefoxOptions options = new FirefoxOptions();
        options.addArguments("--start-maximized");

        // Initialize WebDriver
        WebDriver driver = new FirefoxDriver(options);

        try {
            // Navigate to the application (update URL as necessary)
            driver.get("http://localhost:3000");

            // Wait for the BlogPost card to load
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
            WebElement blogPostCard = wait.until(ExpectedConditions.presenceOfElementLocated(
                By.cssSelector("div.relative.h-\\[432px\\].w-\\[416px\\].rounded-lg.group")
            ));

            // Verify BlogPost card visibility
            if (blogPostCard.isDisplayed()) {
                System.out.println("The BlogPost card is displayed.");
            } else {
                System.out.println("The BlogPost card is not displayed.");
            }

            // Locate the circular button within the BlogPost card
            WebElement circleButton = blogPostCard.findElement(By.cssSelector(
                "div.absolute.bottom-0.right-1.w-\\[114px\\].h-\\[114px\\].rounded-full"
            ));

            // Hover over the circular button to trigger the hover effect
            Actions actions = new Actions(driver);
            actions.moveToElement(circleButton).perform();
            System.out.println("Hovered over the circular button.");

            // Validate hover effect on the button (e.g., background color change)
            String bgColor = circleButton.getCssValue("background-color");
            System.out.println("Button background color after hover: " + bgColor);

            // Click on the circular button
            circleButton.click();
            System.out.println("Circular button clicked successfully.");

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            // Close the browser
            driver.quit();
        }
    }
}
