package BusyQA.SeleniumLearningProject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import java.time.Duration;

public class ShopTropicalPlants {

    public static void main(String[] args) {
        // Set the path to geckodriver
        System.setProperty("webdriver.gecko.driver", "C:\\driver\\geckodriver.exe");

        // Initialize Firefox options
        FirefoxOptions options = new FirefoxOptions();
        options.setHeadless(false);  // Set to true for headless (background) testing

        // Initialize WebDriver for Firefox
        WebDriver driver = new FirefoxDriver(options);

        try {
            // Navigate to the React app (replace with actual URL)
            driver.get("http://localhost:3000");  // Replace with the correct URL where your app is running

            // Wait for the "Shop Tropical Plants" button to be visible
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
            WebElement shopButton = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[text()='Shop Tropical Plants']")));

            // Verify the initial state of the button (button should be visible initially)
            if (shopButton.isDisplayed()) {
                System.out.println("Shop Tropical Plants button is visible initially.");
            } else {
                System.out.println("Shop Tropical Plants button is not visible initially.");
            }

            // Hover over the 'Shop Tropical Plants' button to check the hover effect
            Actions actions = new Actions(driver);
            actions.moveToElement(shopButton).perform();
            System.out.println("Hovered over the Shop Tropical Plants button.");

            // Wait for the hover effect to take place (text color should change)
            Thread.sleep(2000);  // Wait for 2 seconds to observe hover effect

            // Verify hover effect by checking if the text color changes
            String colorBeforeHover = shopButton.getCssValue("color");
            actions.moveToElement(shopButton).perform();
            String colorAfterHover = shopButton.getCssValue("color");

            if (!colorBeforeHover.equals(colorAfterHover)) {
                System.out.println("Hover effect on Shop Tropical Plants button verified.");
            } else {
                System.out.println("Hover effect on Shop Tropical Plants button not verified.");
            }

            // Click the 'Shop Tropical Plants' button
            shopButton.click();
            System.out.println("Clicked on the Shop Tropical Plants button.");

            // Wait for expected outcome after click (modify as per your app's behavior)
            wait.until(ExpectedConditions.urlContains("shop"));

            System.out.println("Test completed successfully.");

        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("An error occurred during test execution.");
        } finally {
            // Close the browser after the test
            driver.quit();
        }
    }
}
