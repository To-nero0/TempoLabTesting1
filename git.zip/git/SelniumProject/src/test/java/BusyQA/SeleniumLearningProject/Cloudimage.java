package BusyQA.SeleniumLearningProject;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class Cloudimage {

    public static void main(String[] args) {
        // Set path to GeckoDriver
        System.setProperty("webdriver.gecko.driver", "C:\\driver\\geckodriver.exe");

        // Configure Firefox browser
        FirefoxOptions options = new FirefoxOptions();
        options.addArguments("--start-maximized");

        // Initialize WebDriver
        WebDriver driver = new FirefoxDriver(options);

        try {
            // Navigate to the application (update URL as necessary)
            driver.get("http://localhost:3000");

            // Wait for the CloudImage component to load
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
            WebElement cloudImageContainer = wait.until(ExpectedConditions.presenceOfElementLocated(
                By.cssSelector("div.w-\\[1441px\\].h-\\[828px\\].relative.group")
            ));

            // Verify CloudImage container visibility
            if (cloudImageContainer.isDisplayed()) {
                System.out.println("The CloudImage container is displayed.");
            } else {
                System.out.println("The CloudImage container is not displayed.");
            }

            // Locate the images within the CloudImage container
            WebElement mainImage = cloudImageContainer.findElement(By.cssSelector("img[src*='Rectangle6.png']"));
            WebElement secondImage = cloudImageContainer.findElement(By.cssSelector("img[src*='a350/2b9f']"));
            WebElement thirdImage = cloudImageContainer.findElement(By.cssSelector("img[src*='9561ce8c41c01f405b55222ec2ad1c89']"));

            // Validate visibility of each image
            System.out.println("Main Image is displayed: " + mainImage.isDisplayed());
            System.out.println("Second Image is displayed: " + secondImage.isDisplayed());
            System.out.println("Third Image is displayed: " + thirdImage.isDisplayed());

            // Hover over the CloudImage container to trigger hover effects
            Actions actions = new Actions(driver);
            actions.moveToElement(cloudImageContainer).perform();
            System.out.println("Hovered over the CloudImage container.");

            // Verify hover effect (e.g., checking for position or style change)
            // You can add specific validations based on the hover effect (position/rotation).
            // Example: Verify the position of the main image after hover
            String mainImagePosition = mainImage.getCssValue("left");
            System.out.println("Main Image position after hover: " + mainImagePosition);

            // Wait for a few seconds to observe the effect
            Thread.sleep(3000);

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            // Close the browser
            driver.quit();
        }
    }
}
