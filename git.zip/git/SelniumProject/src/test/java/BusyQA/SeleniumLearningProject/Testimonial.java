package BusyQA.SeleniumLearningProject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import org.testng.annotations.AfterMethod;
import org.testng.TestNG;

import java.util.Collections;

public class Testimonial {

    WebDriver driver;

    @BeforeMethod
    public void setUp() {
        // Set the path to the geckodriver
        System.setProperty("webdriver.gecko.driver", "C:\\driver\\geckodriver.exe");

        // Initialize the FirefoxDriver
        driver = new FirefoxDriver();
    }

    @Test
    public void testTestimonialText() {
        // Navigate to the website
        driver.get("http://localhost:3000");

        // Find the testimonial text element
        WebElement testimonialText = driver.findElement(By.xpath("//div[@class='w-[742px] h-[106px] text-[#f8f9fb] text-xl font-normal font-[Lufga]']"));

        // Assert that the testimonial text is displayed
        Assert.assertTrue(testimonialText.isDisplayed(), "Testimonial text is not displayed");

        // Optionally, verify the content of the testimonial text
        String expectedText = "consectetur adipiscing elit. Sed congue interdum ligula a dignissim.";
        Assert.assertEquals(testimonialText.getText(), expectedText, "Testimonial text does not match expected text");
    }

    @AfterMethod
    public void tearDown() {
        // Close the browser
        if (driver != null) {
            driver.quit();
        }
    }

    public static void main(String[] args) {
        // Run the TestNG tests using the main method
        TestNG testng = new TestNG();
        testng.setTestClasses(new Class[] { Testimonial.class });
        testng.run();
    }
}
