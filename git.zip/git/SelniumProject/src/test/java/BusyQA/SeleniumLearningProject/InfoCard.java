package BusyQA.SeleniumLearningProject;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import java.time.Duration;

public class InfoCard {
    public static void main(String[] args) {
        // Set path to the GeckoDriver executable
        System.setProperty("webdriver.gecko.driver", "C:\\driver\\geckodriver.exe");

        // Initialize Firefox options
        FirefoxOptions options = new FirefoxOptions();
        options.setHeadless(false); // Set to true if you don't need a visible browser window

        // Initialize the WebDriver for Firefox
        WebDriver driver = new FirefoxDriver(options);

        try {
            // Open the web page that contains the InfoCard component
            driver.get("http://yourwebsite.com"); // Replace with your actual URL

            // Wait for the InfoCard to load and check the background image
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
            WebElement infoCard = wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("relative")));

            // Check if background image is set
            String backgroundImage = infoCard.getCssValue("background-image");
            if (backgroundImage != null && backgroundImage.contains("https://s3-alpha-sig.figma.com")) {
                System.out.println("Background image is loaded correctly.");
            } else {
                System.out.println("Background image is missing or incorrect.");
            }

            // Find the button element and check if it's clickable
            WebElement button = driver.findElement(By.xpath("//button[contains(@class, 'group')]"));
            if (button.isDisplayed() && button.isEnabled()) {
                System.out.println("The button is visible and clickable.");
                button.click();  // Simulate button click
            } else {
                System.out.println("The button is not visible or clickable.");
            }

            // Verify if the title of the InfoCard is present
            WebElement title = driver.findElement(By.tagName("h3"));
            if (title.getText().equals("Calathea")) {
                System.out.println("Title is correct: Calathea.");
            } else {
                System.out.println("Title is incorrect.");
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            // Close the browser after the test
            driver.quit();
        }
    }
}
