package BusyQA.SeleniumLearningProject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class ImageDesign1 {
    public static void main(String[] args) {
        // Set GeckoDriver path
        System.setProperty("webdriver.gecko.driver", "C:\\driver\\geckodriver.exe");

        // Initialize WebDriver
        WebDriver driver = new FirefoxDriver();

        try {
            // Navigate to the React application
            driver.get("http://localhost:3000");

            // Wait for the ImageDesign1 component to load
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
            WebElement imageComponent = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.cssSelector(".relative.w-[603px].h-[600px].group")
            ));

            System.out.println("ImageDesign1 component is visible.");

            // Locate the image element
            WebElement imageElement = imageComponent.findElement(By.tagName("img"));
            System.out.println("Image element found.");

            // Verify image source
            String imageUrl = imageElement.getAttribute("src");
            if (imageUrl.contains("https://s3-alpha-sig.figma.com")) {
                System.out.println("Image source URL is correct.");
            } else {
                System.out.println("Image source URL is incorrect: " + imageUrl);
            }

            // Verify image dimensions
            String imageWidth = imageElement.getCssValue("width");
            String imageHeight = imageElement.getCssValue("height");
            System.out.println("Image Dimensions - Width: " + imageWidth + ", Height: " + imageHeight);

            // Perform hover action to reveal circular borders
            Actions actions = new Actions(driver);
            actions.moveToElement(imageElement).perform();
            System.out.println("Hover action performed.");

            // Verify circular borders appear
            for (int i = 1; i <= 6; i++) {
                WebElement border = imageComponent.findElement(By.cssSelector(
                    ".absolute:nth-of-type(" + i + ")"
                ));
                String opacity = border.getCssValue("opacity");
                if (opacity.equals("1")) {
                    System.out.println("Circular border " + i + " is visible on hover.");
                } else {
                    System.out.println("Circular border " + i + " is not visible: Opacity = " + opacity);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            // Close the browser
            driver.quit();
        }
    }
}
