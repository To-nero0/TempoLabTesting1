package BusyQA.SeleniumLearningProject;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

public class WhiteArrowButton {
    public static void main(String[] args) {
        // Set the path to geckodriver
        System.setProperty("webdriver.gecko.driver", "C:\\driver\\geckodriver.exe");

        // Initialize WebDriver for Firefox
        WebDriver driver = new FirefoxDriver();

        try {
            // Navigate to the web page hosting the WhiteArrowButton component
            driver.get("http://localhost:3000"); // Replace with your local development server or deployed URL

            // Maximize the browser window
            driver.manage().window().maximize();

            // Locate the button by its CSS class
            WebElement button = driver.findElement(By.cssSelector("button.w-[92px].h-[92px]"));

            // Verify button visibility
            if (button.isDisplayed()) {
                System.out.println("WhiteArrowButton is displayed on the page.");
            } else {
                System.out.println("WhiteArrowButton is not visible.");
            }

            // Locate the SVG element within the button
            WebElement svgElement = button.findElement(By.tagName("svg"));

            // Verify the rotation transformation of the SVG element
            String transformAttribute = svgElement.getAttribute("class");
            if (transformAttribute != null && transformAttribute.contains("rotate-90")) {
                System.out.println("SVG element within the button is rotated correctly.");
            } else {
                System.out.println("SVG element rotation is incorrect or missing.");
            }
        } catch (Exception e) {
            // Handle any exceptions during the test
            e.printStackTrace();
        } finally {
            // Close the browser
            driver.quit();
        }
    }
}

