package BusyQA.SeleniumLearningProject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class HireMePortfolio {
    public static void main(String[] args) {
        // Set GeckoDriver path
        System.setProperty("webdriver.gecko.driver", "C:\\driver\\geckodriver.exe");

        // Initialize WebDriver
        WebDriver driver = new FirefoxDriver();

        try {
            // Navigate to the React application
            driver.get("http://localhost:3000");

            // Wait for the "HireMePortfolio" component to load
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
            WebElement portfolioContainer = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.cssSelector(".flex.justify-center.items-center.h-screen.bg-gray-800")
            ));

            System.out.println("HireMePortfolio component is visible.");

            // Locate the "Portfolio" button
            WebElement portfolioButton = portfolioContainer.findElement(By.xpath(".//div[contains(text(),'Portfolio')]"));
            System.out.println("Portfolio button found.");

            // Verify CSS properties of "Portfolio" button
            String portfolioBgColor = portfolioButton.getCssValue("background-color");
            System.out.println("Portfolio Button Background Color: " + portfolioBgColor);

            // Locate the "Hire Me" button
            WebElement hireMeButton = portfolioContainer.findElement(By.xpath(".//div[contains(text(),'Hire me')]"));
            System.out.println("Hire Me button found.");

            // Verify CSS properties of "Hire Me" button
            String hireMeBgColor = hireMeButton.getCssValue("background-color");
            System.out.println("Hire Me Button Background Color: " + hireMeBgColor);

            // Click the "Portfolio" button
            portfolioButton.click();
            System.out.println("Portfolio button clicked.");

            // Click the "Hire Me" button
            hireMeButton.click();
            System.out.println("Hire Me button clicked.");

            // Verify SVG in "Hire Me" button
            WebElement svgIcon = hireMeButton.findElement(By.tagName("svg"));
            if (svgIcon.isDisplayed()) {
                System.out.println("SVG icon is visible in Hire Me button.");
            } else {
                System.out.println("SVG icon is not visible in Hire Me button.");
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            // Close the browser
            driver.quit();
        }
    }
}
