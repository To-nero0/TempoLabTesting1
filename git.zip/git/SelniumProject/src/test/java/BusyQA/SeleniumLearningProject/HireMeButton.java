package BusyQA.SeleniumLearningProject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class HireMeButton {
    public static void main(String[] args) {
        // Set the path for GeckoDriver
        System.setProperty("webdriver.gecko.driver", "C:\\driver\\geckodriver.exe");

        // Initialize WebDriver
        WebDriver driver = new FirefoxDriver();

        try {
            // Open the React application
            driver.get("http://localhost:3000");

            // Wait for the button to load
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
            WebElement hireMeButton = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.cssSelector(".w-[202px].bg-[#fd8439].rounded-[60px]")
            ));

            // Validate button visibility
            if (hireMeButton.isDisplayed()) {
                System.out.println("Hire Me button is visible.");
            } else {
                System.out.println("Hire Me button is not visible.");
            }

            // Validate CSS properties
            String backgroundColor = hireMeButton.getCssValue("background-color");
            String borderRadius = hireMeButton.getCssValue("border-radius");
            System.out.println("Background Color: " + backgroundColor);
            System.out.println("Border Radius: " + borderRadius);

            // Validate button text
            WebElement buttonText = hireMeButton.findElement(By.cssSelector(".text-white"));
            String text = buttonText.getText();
            System.out.println("Button Text: " + text);

            // Simulate hover action and validate icon change
            Actions actions = new Actions(driver);
            actions.moveToElement(hireMeButton).perform();

            // Wait for the hover icon to load
            WebElement hoverIcon = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.cssSelector("svg > g > path#Vector")
            ));

            if (hoverIcon.isDisplayed()) {
                System.out.println("Hover icon is displayed.");
            } else {
                System.out.println("Hover icon is not displayed.");
            }

            // Perform click action
            hireMeButton.click();
            System.out.println("Hire Me button clicked successfully!");

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            // Close the browser
            driver.quit();
        }
    }
}
