package BusyQA.SeleniumLearningProject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class GreyWhiteHomeButton {
    public static void main(String[] args) {
        // Set path for GeckoDriver
        System.setProperty("webdriver.gecko.driver", "C:\\driver\\geckodriver.exe");

        // Initialize WebDriver
        WebDriver driver = new FirefoxDriver();

        try {
            // Open the React application
            driver.get("http://localhost:3000");

            // Wait for the button to load
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
            WebElement homeButton = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.cssSelector(".h-[66px].bg-white\\/10.rounded-[60px]")
            ));

            // Validate button visibility
            if (homeButton.isDisplayed()) {
                System.out.println("Home button is visible.");
            } else {
                System.out.println("Home button is not visible.");
            }

            // Validate CSS properties
            String backgroundColor = homeButton.getCssValue("background-color");
            String borderRadius = homeButton.getCssValue("border-radius");
            System.out.println("Background Color: " + backgroundColor);
            System.out.println("Border Radius: " + borderRadius);

            // Validate inner text and font properties
            WebElement textElement = homeButton.findElement(By.cssSelector(".text-white"));
            String buttonText = textElement.getText();
            String fontSize = textElement.getCssValue("font-size");
            String fontFamily = textElement.getCssValue("font-family");
            System.out.println("Button Text: " + buttonText);
            System.out.println("Font Size: " + fontSize);
            System.out.println("Font Family: " + fontFamily);

            // Perform click action
            homeButton.click();
            System.out.println("Home button clicked successfully!");

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            // Close the browser
            driver.quit();
        }
    }
}
