package BusyQA.SeleniumLearningProject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class BlackArrowButton45Degrees{

    public static void main(String[] args) {
       
        System.setProperty("webdriver.gecko.driver", "C:\\driver\\geckodriver.exe");

        FirefoxOptions options = new FirefoxOptions();
        options.addArguments("--start-maximized");

      
        WebDriver driver = new FirefoxDriver(options);

        try {
          
            driver.get("http://localhost:3000");

           
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

           
            WebElement button = wait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector("button.w-\\[92px\\]")));

         
            if (button.isDisplayed()) {
                System.out.println("Black Arrow Button is displayed.");
            } else {
                System.out.println("Black Arrow Button is not displayed.");
            }

         
            String rotation = button.getCssValue("transform");
            System.out.println("Button rotation: " + rotation);

            String backgroundColor = button.getCssValue("background-color");
            System.out.println("Button background color: " + backgroundColor);

            WebElement svg = button.findElement(By.tagName("svg"));
            if (svg != null) {
                System.out.println("SVG arrow icon is present.");

              
                String svgRotation = svg.getAttribute("class");
                if (svgRotation.contains("rotate-[45deg]")) {
                    System.out.println("SVG arrow rotation is correctly set to 45 degrees.");
                } else {
                    System.out.println("SVG arrow rotation is not set correctly.");
                }
            } else {
                System.out.println("SVG arrow icon is missing.");
            }

          
            button.click();
            System.out.println("Button clicked successfully.");

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
           
            driver.quit();
        }
    }
}
