package BusyQA.SeleniumLearningProject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class GreySearchButton {
    public static void main(String[] args) {
        // Set the path for GeckoDriver
        System.setProperty("webdriver.gecko.driver", "C:\\driver\\geckodriver.exe");

        // Initialize WebDriver
        WebDriver driver = new FirefoxDriver();

        try {
            // Open the React application
            driver.get("http://localhost:3000");

            // Wait for the button to load
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
            WebElement searchButton = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.cssSelector(".w-[92px].h-[92px].rounded-[57px].bg-[#808080]")
            ));

            // Validate button visibility
            if (searchButton.isDisplayed()) {
                System.out.println("Search button is visible.");
            } else {
                System.out.println("Search button is not visible.");
            }

            // Validate CSS properties
            String backgroundColor = searchButton.getCssValue("background-color");
            String borderRadius = searchButton.getCssValue("border-radius");
            System.out.println("Background Color: " + backgroundColor);
            System.out.println("Border Radius: " + borderRadius);

            // Validate SVG properties
            WebElement svgElement = searchButton.findElement(By.tagName("svg"));
            String svgWidth = svgElement.getAttribute("width");
            String svgHeight = svgElement.getAttribute("height");
            System.out.println("SVG Width: " + svgWidth);
            System.out.println("SVG Height: " + svgHeight);

            // Perform click action
            searchButton.click();
            System.out.println("Search button clicked successfully!");

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            // Close the browser
            driver.quit();
        }
    }
}
