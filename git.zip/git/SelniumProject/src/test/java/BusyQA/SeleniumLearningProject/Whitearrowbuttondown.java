package BusyQA.SeleniumLearningProject;



	import org.openqa.selenium.By;
	import org.openqa.selenium.WebDriver;
	import org.openqa.selenium.WebElement;
	import org.openqa.selenium.firefox.FirefoxDriver;
	import org.openqa.selenium.firefox.FirefoxOptions;

	public class Whitearrowbuttondown {
	    public static void main(String[] args) {
	        // Path to the GeckoDriver
	        System.setProperty("webdriver.gecko.driver", "C:\\driver\\geckodriver.exe");

	        // Set up Firefox options (optional)
	        FirefoxOptions options = new FirefoxOptions();
	        options.addArguments("--start-maximized");

	        // Initialize the WebDriver
	        WebDriver driver = new FirefoxDriver(options);

	        try {
	            // Navigate to the webpage hosting the React component
	            driver.get("http://localhost:3000"); // Replace with your actual URL

	            // Locate the button by its CSS class
	            WebElement button = driver.findElement(By.cssSelector(".w-[92px].h-[92px].-rotate-90"));

	            // Verify the button is displayed
	            if (button.isDisplayed()) {
	                System.out.println("Button is displayed successfully.");
	            } else {
	                System.out.println("Button is not displayed.");
	            }

	            // Locate the SVG element within the button
	            WebElement svgElement = button.findElement(By.cssSelector("svg.transform.rotate-[180deg]"));

	            // Verify the SVG element is present and oriented correctly
	            if (svgElement != null) {
	                System.out.println("SVG element is present and rotated correctly.");
	            } else {
	                System.out.println("SVG element is missing or not rotated as expected.");
	            }
	        } catch (Exception e) {
	            System.err.println("An error occurred during the test: " + e.getMessage());
	        } finally {
	            // Close the browser
	            driver.quit();
	        }
	    }
	}
