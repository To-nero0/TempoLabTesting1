package BusyQA.SeleniumLearningProject;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import java.time.Duration;

public class PortfolioToggleButton {

    public static void main(String[] args) {
        // Set the path to geckodriver
        System.setProperty("webdriver.gecko.driver", "C:\\driver\\geckodriver.exe");

        // Initialize Firefox options
        FirefoxOptions options = new FirefoxOptions();
        options.setHeadless(false);  // Set to true for headless (background) testing

        // Initialize WebDriver for Firefox
        WebDriver driver = new FirefoxDriver(options);

        try {
            // Navigate to the React app (make sure it’s running locally)
            driver.get("http://localhost:3000");  // Replace with the correct URL where your app is running

            // Wait for the 'Portfolio' and 'Hire Me' buttons to be visible
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
            WebElement portfolioButton = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[text()='Portfolio']")));
            WebElement hireMeButton = driver.findElement(By.xpath("//div[text()='Hire me']"));

            // Verify the initial state of the buttons
            if (portfolioButton.isDisplayed()) {
                System.out.println("Portfolio button is visible initially.");
            } else {
                System.out.println("Portfolio button is not visible initially.");
            }

            if (hireMeButton.isDisplayed()) {
                System.out.println("Hire Me button is visible initially.");
            } else {
                System.out.println("Hire Me button is not visible initially.");
            }

            // Hover over the 'Hire Me' button to check the hover effect
            Actions actions = new Actions(driver);
            actions.moveToElement(hireMeButton).perform();
            System.out.println("Hovered over the Hire Me button.");

            // Wait for the hover effect to take place (button style should change)
            Thread.sleep(2000);  // Wait for 2 seconds to observe hover effect

            // Verify hover effect by checking if the button's text style has changed
            WebElement hireMeButtonAfterHover = driver.findElement(By.xpath("//div[text()='Hire me']"));
            String fontWeightAfterHover = hireMeButtonAfterHover.getCssValue("font-weight");
            if (fontWeightAfterHover.equals("700")) {  // Font weight should change when hovered
                System.out.println("Hover effect on Hire Me button verified.");
            } else {
                System.out.println("Hover effect on Hire Me button not verified.");
            }

            // Hover back to 'Portfolio' button and check the style
            actions.moveToElement(portfolioButton).perform();
            System.out.println("Hovered over the Portfolio button.");
            Thread.sleep(2000);  // Wait for 2 seconds to observe hover effect

            // Verify hover effect by checking if the font-weight of 'Portfolio' changes
            WebElement portfolioButtonAfterHover = driver.findElement(By.xpath("//div[text()='Portfolio']"));
            String fontWeightPortfolioAfterHover = portfolioButtonAfterHover.getCssValue("font-weight");
            if (fontWeightPortfolioAfterHover.equals("300")) {  // Font weight should change when hovered
                System.out.println("Hover effect on Portfolio button verified.");
            } else {
                System.out.println("Hover effect on Portfolio button not verified.");
            }

            // Click the 'Portfolio' button
            portfolioButton.click();
            System.out.println("Clicked on the Portfolio button.");

            // Wait for expected outcome after click (modify as per your app's behavior)
            wait.until(ExpectedConditions.urlContains("portfolio"));

            // Click the 'Hire Me' button
            hireMeButton.click();
            System.out.println("Clicked on the Hire Me button.");

            // Wait for expected outcome after click (modify as per your app's behavior)
            wait.until(ExpectedConditions.urlContains("hireme"));

            System.out.println("Test completed successfully.");

        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("An error occurred during test execution.");
        } finally {
            // Close the browser after the test
            driver.quit();
        }
    }
}
