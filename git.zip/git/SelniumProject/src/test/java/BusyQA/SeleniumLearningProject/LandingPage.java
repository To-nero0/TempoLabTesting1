package BusyQA.SeleniumLearningProject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.openqa.selenium.firefox.GeckoDriverService;
import org.openqa.selenium.remote.service.DriverService;

public class LandingPage {

    WebDriver driver;
    
    // Path to your geckodriver executable
    String geckoDriverPath = "C:\\driver\\geckodriver.exe";
    
    @BeforeTest
    public void setup() {
        // Set system property for geckodriver
        System.setProperty("webdriver.gecko.driver", geckoDriverPath);

        // Set options for Firefox browser
        FirefoxOptions options = new FirefoxOptions();
        options.addArguments("--headless"); // Run Firefox in headless mode (without UI)
        
        // Initialize the Firefox driver
        driver = new FirefoxDriver(options);
    }

    @Test
    public void testLandingPage() {
        // Navigate to the page
        driver.get("http://your-landing-page-url.com");

        // Verify the presence of key elements on the landing page

        // Check if the "Portfolio" button is visible
        WebElement portfolioButton = driver.findElement(By.xpath("//div[text()='Portfolio']"));
        Assert.assertTrue(portfolioButton.isDisplayed(), "Portfolio button is not visible");

        // Check if the "Hire me" button is visible
        WebElement hireMeButton = driver.findElement(By.xpath("//div[text()='Hire me']"));
        Assert.assertTrue(hireMeButton.isDisplayed(), "Hire me button is not visible");

        // Check if the image is visible
        WebElement portfolioImage = driver.findElement(By.xpath("//img[@alt='Jenny's Portfolio']"));
        Assert.assertTrue(portfolioImage.isDisplayed(), "Portfolio image is not visible");

        // Verify the header text ("Jenny")
        WebElement headerText = driver.findElement(By.xpath("//span[text()='Jenny']"));
        Assert.assertTrue(headerText.isDisplayed(), "Header text is not visible");

        // Verify the "10 Years Experience" section
        WebElement experienceText = driver.findElement(By.xpath("//div[text()='10 Years']"));
        Assert.assertTrue(experienceText.isDisplayed(), "Experience text is not visible");
    }
}
