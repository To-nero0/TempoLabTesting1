package BusyQA.SeleniumLearningProject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.WebDriverException;

import java.time.Duration;

public class OrangeHomeButton {
    public static void main(String[] args) {
        // Set path to geckodriver
        System.setProperty("webdriver.gecko.driver", "C:\\driver\\geckodriver.exe");

        // Initialize Firefox options
        FirefoxOptions options = new FirefoxOptions();
        options.setHeadless(false);  // Set to true to run tests without UI

        // Initialize WebDriver (Firefox)
        WebDriver driver = new FirefoxDriver(options);

        try {
            // Open the web page that contains the OrangeHomeButton component
            driver.get("http://localhost:3000"); // Replace with actual URL of your React app
            
            // Wait for the "Home" button to be visible and clickable
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
            WebElement homeButton = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'Home')]")));

            // Verify that the button is displayed and clickable
            if (homeButton.isDisplayed() && homeButton.isEnabled()) {
                System.out.println("OrangeHomeButton is visible and enabled.");
            } else {
                System.out.println("OrangeHomeButton is not visible or enabled.");
            }

            // Click the Home button
            homeButton.click();

            // Wait to see the action or change
            wait.until(ExpectedConditions.urlContains("expected-page-url"));  // Modify to the expected URL after the button click

            System.out.println("Button clicked and new page loaded.");

        } catch (WebDriverException e) {
            e.printStackTrace();
            System.out.println("Error occurred during test execution.");
        } finally {
            // Close the browser
            driver.quit();
        }
    }
}
