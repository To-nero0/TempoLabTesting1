package BusyQA.SeleniumLearningProject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import java.time.Duration;

public class PortfolioHireMe {

    public static void main(String[] args) {
        // Set path to geckodriver
        System.setProperty("webdriver.gecko.driver", "C:\\driver\\geckodriver.exe");

        // Initialize Firefox options
        FirefoxOptions options = new FirefoxOptions();
        options.setHeadless(false);  // Set to true for headless (background) testing

        // Initialize WebDriver for Firefox
        WebDriver driver = new FirefoxDriver(options);

        try {
            // Navigate to the React app (make sure it’s running locally)
            driver.get("http://localhost:3000");  // Replace with the correct URL

            // Wait for the 'Portfolio' button to be visible
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
            WebElement portfolioButton = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[text()='Portfolio']")));

            // Verify that the 'Portfolio' button is visible
            if (portfolioButton.isDisplayed()) {
                System.out.println("Portfolio button is visible.");
            } else {
                System.out.println("Portfolio button is not visible.");
            }

            // Verify that the 'Hire Me' button is visible
            WebElement hireMeButton = driver.findElement(By.xpath("//div[text()='Hire me']"));
            if (hireMeButton.isDisplayed()) {
                System.out.println("Hire me button is visible.");
            } else {
                System.out.println("Hire me button is not visible.");
            }

            // Hover over the 'Portfolio' button to check hover effect
            Actions actions = new Actions(driver);
            actions.moveToElement(portfolioButton).perform();
            System.out.println("Hovered over the Portfolio button.");

            // Click on the 'Portfolio' button
            portfolioButton.click();
            System.out.println("Clicked on the Portfolio button.");

            // Click on the 'Hire Me' button
            hireMeButton.click();
            System.out.println("Clicked on the Hire Me button.");

            // Wait for the expected outcome after clicking (if there's a page change or modal)
            wait.until(ExpectedConditions.urlContains("portfolio"));  // Modify as necessary

            System.out.println("Test completed successfully.");

        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("An error occurred during test execution.");
        } finally {
            // Close the browser after the test
            driver.quit();
        }
    }
}
