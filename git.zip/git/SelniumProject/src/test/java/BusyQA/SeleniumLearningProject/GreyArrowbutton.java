package BusyQA.SeleniumLearningProject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import java.time.Duration;

public class GreyArrowbutton {
    public static void main(String[] args) {
        // Set the path to the geckodriver executable
        System.setProperty("webdriver.gecko.driver", "C:\\driver\\geckodriver.exe");

        // Initialize Firefox WebDriver
        FirefoxOptions options = new FirefoxOptions();
        WebDriver driver = new FirefoxDriver(options);

        try {
            // Navigate to the React application containing the GreyArrowButton component
            driver.get("http://localhost:3000"); // Update with your app's actual URL

            // Maximize the browser window for better visibility
            driver.manage().window().maximize();

            // Wait for the button to be visible
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
            WebElement button = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.cssSelector("button.w-[92px].h-[92px].bg-[#808080]")));

            // Verify the button's attributes
            String buttonColor = button.getCssValue("background-color");
            String buttonWidth = button.getCssValue("width");
            String buttonHeight = button.getCssValue("height");

            System.out.println("Button Background Color: " + buttonColor);
            System.out.println("Button Width: " + buttonWidth);
            System.out.println("Button Height: " + buttonHeight);

            // Check for the SVG element inside the button
            WebElement svgElement = button.findElement(By.tagName("svg"));
            if (svgElement.isDisplayed()) {
                System.out.println("SVG Arrow is present inside the button.");
            } else {
                System.out.println("SVG Arrow is not present.");
            }

            // Check if the SVG arrow is correctly rotated
            String svgTransform = svgElement.getAttribute("class");
            if (svgTransform.contains("rotate-90")) {
                System.out.println("SVG Arrow is correctly rotated.");
            } else {
                System.out.println("SVG Arrow is not correctly rotated.");
            }

        } catch (Exception e) {
            System.out.println("An error occurred: " + e.getMessage());
        } finally {
            // Close the driver
            driver.quit();
        }
    }
}
